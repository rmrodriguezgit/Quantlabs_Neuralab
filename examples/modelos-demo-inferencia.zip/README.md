# Ganadores por familia

Cada subcarpeta es un paquete independiente de inferencia. Ver su README y manifest. selection_report.json conserva variantes, validación y test reservado. Los scripts funcionan en modo paper y no envían órdenes.
