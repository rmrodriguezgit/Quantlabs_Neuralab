# Paquete de inferencia financiera

Contiene arquitectura, modelos Keras sin estado de optimizador, pesos NPZ, escalas, configuración, métricas y contexto OHLC para reproducir indicadores. No contiene claves ni envía órdenes.

```bash
python -m venv .venv
# Activar .venv según tu sistema
pip install -r requirements.txt
python bot_infer.py --bundle . --output signal.json
python bot_infer.py --bundle . --csv barras_nuevas.csv --output signal.json
```

CSV: date ISO y Open, High, Low, Close. Usa barras diarias cerradas y las mismas convenciones de ajuste de precios. El contexto es histórico para indicadores; no implica que los pesos se hayan entrenado con test. `--asof FECHA` permite inferencia retrospectiva con contexto cortado. `--asset 0` elige el primer activo; `--position -1/0/1` informa la posición al modelo de trading. Generadores aceptan `--scenarios 32`.

`.keras` conserva arquitectura y pesos; `*.weights.npz` incluye los arrays en el orden descrito por el manifest. Ridge/PCA utilizan JSON numérico, sin pickle. Los pesos de TensorFlow necesitan adaptación de disposición si se reconstruyen en otro framework. El paquete está preparado para inferencia, no para reanudar el optimizador en el estado exacto del checkpoint.

Una integración con broker debe implementar tamaño, calendario, controles de riesgo, ejecución, persistencia, observabilidad y pruebas en paper. Las señales y escenarios son experimentales; sus métricas históricas no garantizan rentabilidad.
